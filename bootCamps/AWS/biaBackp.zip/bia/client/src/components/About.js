import { Link } from "react-router-dom";
const About = () => {
  return (
    <div>
      <h4>Versão 1.0.1</h4>
      <h5>BIA 17 a 20 de Janeiro/2022</h5>
      <Link to="/">Voltar</Link>
    </div>
  );
};

export default About;
