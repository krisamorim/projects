## Projeto base para o evento Bootcamp Imersão AWS com Docker que irei realizar no meu canal do Youtube.

### Período do evento: 17 a 20 de Janeiro/2022 (Online e ao vivo às 20h)

[>> Página de Inscrição do evento](https://inscricao.imersaoaws.com.br)

